package com.black.ai

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Contêiner simples de dependências (sem framework de DI). */
class Container(ctx: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val db = Room.databaseBuilder(ctx, BlackDb::class.java, "black.db").build()
    val dao: BlackDao = db.dao()
    val settings = Settings(ctx)
    val net = ConnectivityMonitor(ctx)
    val logger = ActionLogger(dao)
    val perms = PermissionManager(logger)
    val tools = ToolRegistry(settings)
    val modelStore = ModelStore(ctx, settings, scope)
    val local = LocalEngine(ctx, modelStore)
    val llm = LlmRouter(
        online = { net.state.value != NetState.OFFLINE && !settings.forceOffline.value },
        preferLocal = { settings.preferLocal.value },
        local = local,
        remote = RemoteEngine(settings)
    )
    val memory = MemoryAgent(dao, logger)
    private val security = SecurityAgent(perms)
    val webResearch = WebResearch()
    val researchAgent = ResearchAgent(webResearch, llm)
    val planningAgent = PlanningAgent(llm)
    val analystAgent = AnalystAgent(llm)
    val core = BlackCore(scope, dao, llm, memory, security, perms, tools, logger,
        researchAgent, planningAgent, analystAgent,
        { net.state.value != NetState.OFFLINE && !settings.forceOffline.value })
}

class BlackApp : Application() {
    lateinit var container: Container
    override fun onCreate() {
        super.onCreate()
        container = Container(applicationContext)
    }

    /** Em segundo plano, libera a RAM do modelo local. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            container.scope.launch { container.local.unload() }
        }
    }
}
