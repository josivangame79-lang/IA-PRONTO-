# Etapa 5 — BLACK TOOLBOX (0.5.0)

A Etapa 5 acrescenta ferramentas Android locais e conectores públicos, mantendo a autonomia CONTROLLED.

## Disponível nesta versão

| Ferramenta | O que faz | Limites |
|---|---|---|
| Calculadora segura | Avalia expressões com `+ - * / ^` e parênteses | Sem funções científicas avançadas; não executa scripts |
| BLACK CODE | Análise estática de trechos de código: segredos aparentes, `!!`, TODO/FIXME, HTTP, blocos catch vazios e balanceamento | Heurísticas simples; não compila, executa nem substitui revisão profissional |
| GitHub | Pesquisa até cinco repositórios públicos pela API oficial | Sem login, escrita, issues, commits ou acesso a repositórios privados |
| Tradução | Traduz texto pt → en pelo MyMemory | Requer internet; serviço externo pode limitar pedidos; revise traduções |
| Arquivos | Abre texto/JSON/XML e salva TXT/CSV usando o seletor de documentos Android | Acesso apenas aos arquivos escolhidos; limite de leitura de 1 MB e gravação de 2 MB |
| Calendário | Abre um app de calendário com um evento preenchido para confirmação | O usuário revisa e confirma no app externo; não grava silenciosamente |
| Compartilhar | Abre o seletor Android para compartilhar texto | O usuário escolhe o destino e confirma |
| Histórico/backup | Mantém histórico, memórias e backup JSON da etapa 4 | Backup manual; guarde o arquivo em local privado |
| Pesquisa web/acadêmica | DuckDuckGo e Crossref | Exige internet; snippets/metadados não substituem leitura das fontes |
| Voz | Reconhecimento de fala e Text-to-Speech do Android | Disponibilidade e processamento offline dependem do aparelho/serviço instalado |
| IA online/offline | API compatível OpenAI e LiteRT-LM | LiteRT-LM/modelo real precisa ser validado no dispositivo arm64 |

## Como usar

Abra a aba **Ferramentas**. O painel BLACK TOOLBOX oferece calculadora, análise de código, busca GitHub, tradução, abertura/salvamento de arquivos, exportação CSV, criação de evento no calendário e compartilhamento.

## Segurança e privacidade

- Nenhum código colado é executado. A análise é somente estática.
- O seletor de documentos do Android concede acesso somente ao arquivo escolhido.
- A pesquisa GitHub e tradução enviam a consulta ao respectivo serviço externo.
- Calendário e compartilhamento abrem aplicativos externos para revisão e confirmação.
- Não foram adicionadas rotinas para compras, envio automático de mensagens, exclusão de arquivos, alteração de repositórios ou execução remota.
- A chave do servidor de IA continua no armazenamento criptografado existente.

## Ainda não disponível

- Análise/geração de imagens: requer endpoint de visão/geração e uma interface de seleção/retorno de imagem.
- PDF, DOCX, XLSX e PPTX nativos: esta etapa exporta TXT/CSV; formatos avançados exigem bibliotecas e testes próprios.
- GitHub autenticado e operações de escrita: exigem OAuth/token protegido, escopos mínimos e confirmação por ação.
- Integração de calendário em segundo plano: não incluída; a versão atual abre o app de calendário.
- Execução de código em sandbox: não incluída deliberadamente para evitar executar código não confiável no próprio processo do app.

## Validação

Foram adicionados testes unitários para precedência da calculadora, divisão por zero, análise estática e escaping CSV. O projeto foi editado e empacotado, mas não compilado nesta sessão: não há Android SDK/Gradle configurado no ambiente. Execute no GitHub Actions `:app:testDebugUnitTest` e `:app:assembleDebug` e revise os logs antes de instalar.
