package com.black.ai

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

data class ModelFile(val name: String, val sizeBytes: Long)

data class ImportState(
    val running: Boolean = false,
    val copied: Long = 0,
    val total: Long = -1,
    val error: String? = null,
    val done: String? = null
)

/** Gerenciador de modelos locais: importa .litertlm escolhido pelo usuário para o armazenamento privado do app. */
class ModelStore(private val ctx: Context, private val settings: Settings, private val scope: CoroutineScope) {
    private val dir = File(ctx.filesDir, "models").apply { mkdirs() }

    private val _models = MutableStateFlow(scan())
    val models: StateFlow<List<ModelFile>> = _models

    private val _active = MutableStateFlow<String?>(settings.activeModel.ifBlank { null })
    val active: StateFlow<String?> = _active

    val importState = MutableStateFlow(ImportState())
    private var importJob: Job? = null

    private fun scan(): List<ModelFile> =
        dir.listFiles { f -> f.isFile && f.name.endsWith(".litertlm") }
            ?.map { ModelFile(it.name, it.length()) }?.sortedBy { it.name } ?: emptyList()

    private fun refresh() { _models.value = scan() }

    fun activeFile(): File? {
        val n = _active.value ?: return null
        val f = File(dir, n)
        return if (f.isFile) f else null
    }

    fun setActive(name: String?) {
        settings.activeModel = name ?: ""
        _active.value = name
    }

    fun delete(name: String) {
        File(dir, name).delete()
        if (_active.value == name) setActive(null)
        refresh()
    }

    fun cancelImport() { importJob?.cancel() }

    fun importFrom(uri: Uri) {
        if (importJob?.isActive == true) return
        importJob = scope.launch(Dispatchers.IO) {
            var tmp: File? = null
            try {
                var displayName: String? = null
                var total = -1L
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) displayName = c.getString(ni)
                        if (si >= 0 && !c.isNull(si)) total = c.getLong(si)
                    }
                }
                val name = File(displayName ?: "modelo.litertlm").name
                if (!name.endsWith(".litertlm")) throw IOException("O arquivo precisa ter a extensão .litertlm")
                if (total > 0 && dir.usableSpace < total + 100L * 1024 * 1024) {
                    throw IOException("Espaço insuficiente no aparelho para este modelo")
                }
                importState.value = ImportState(running = true, total = total)
                val part = File(dir, "$name.part")
                tmp = part
                val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Não foi possível abrir o arquivo")
                input.use { inp ->
                    part.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var copied = 0L
                        while (true) {
                            ensureActive()
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copied += n
                            importState.value = ImportState(running = true, copied = copied, total = total)
                        }
                    }
                }
                val dest = File(dir, name)
                if (dest.exists()) dest.delete()
                if (!part.renameTo(dest)) throw IOException("Falha ao salvar o modelo")
                tmp = null
                refresh()
                if (_active.value == null) setActive(name)
                importState.value = ImportState(done = name)
            } catch (e: CancellationException) {
                tmp?.delete()
                importState.value = ImportState(error = "Importação cancelada")
                throw e
            } catch (e: Exception) {
                tmp?.delete()
                importState.value = ImportState(error = e.message ?: e.javaClass.simpleName)
            }
        }
    }
}
