package com.black.ai

/** Interpretação simples de comandos (pura, sem Android, testável em JVM). */
sealed class Intent {
    data class Remember(val text: String) : Intent()
    data class Recall(val query: String) : Intent()
    data class Sensitive(val action: SensitiveAction) : Intent()
    object TimeQuery : Intent()
    object Chat : Intent()
}

object CommandParser {
    private val remember = Regex("""^\s*(lembre-se|lembre|lembra|guarde|anote)\s*(que|:)?\s*(.+)$""", RegexOption.IGNORE_CASE)
    private val recall = Regex(
        """^\s*(o que (você |voce |vc )?(sabe|lembra)( de| sobre)?|buscar memória( sobre)?|busque na memória( sobre)?)\s+(.+?)\??\s*$""",
        RegexOption.IGNORE_CASE
    )
    private val time = Regex("""(que horas|que dia é hoje|que dia e hoje|data de hoje|qual a data)""", RegexOption.IGNORE_CASE)

    private val sensitive: List<Pair<Regex, SensitiveAction>> = listOf(
        Regex("""\b(envie|enviar|mande|mandar)\b.*\b(mensagem|whatsapp|email|e-mail|sms)\b""", RegexOption.IGNORE_CASE) to SensitiveAction.SEND_MESSAGE,
        Regex("""\b(compre|comprar|pague|pagar)\b""", RegexOption.IGNORE_CASE) to SensitiveAction.PURCHASE,
        Regex("""\b(exclua|excluir|apague|apagar|delete|deletar)\b.*\b(arquivo|arquivos|pasta|foto|fotos)\b""", RegexOption.IGNORE_CASE) to SensitiveAction.DELETE_FILE,
        Regex("""\b(acesse|acessar|entre|entrar)\b.*\b(conta|senha|banco)\b""", RegexOption.IGNORE_CASE) to SensitiveAction.ACCESS_PRIVATE,
        Regex("""\b(modifique|modificar|altere|alterar)\b.*(seu núcleo|seu nucleo|seu código|seu codigo|você mesmo|voce mesmo)""", RegexOption.IGNORE_CASE) to SensitiveAction.MODIFY_CORE
    )

    fun parse(input: String): Intent {
        sensitive.firstOrNull { it.first.containsMatchIn(input) }?.let { return Intent.Sensitive(it.second) }
        remember.matchEntire(input)?.let { return Intent.Remember(it.groupValues[3].trim()) }
        recall.matchEntire(input)?.let { return Intent.Recall(it.groupValues[7].trim()) }
        if (time.containsMatchIn(input)) return Intent.TimeQuery
        return Intent.Chat
    }
}
