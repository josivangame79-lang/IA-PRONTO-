package com.black.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    @Test fun remember() {
        val i = CommandParser.parse("lembre que meu aniversário é em março")
        assertEquals(Intent.Remember("meu aniversário é em março"), i)
    }

    @Test fun recall() {
        val i = CommandParser.parse("o que você sabe sobre aniversário?")
        assertEquals(Intent.Recall("aniversário"), i)
    }

    @Test fun time() {
        assertEquals(Intent.TimeQuery, CommandParser.parse("que horas são"))
    }

    @Test fun sensitiveActionsAreGated() {
        assertEquals(Intent.Sensitive(SensitiveAction.SEND_MESSAGE), CommandParser.parse("envie uma mensagem para o João"))
        assertEquals(Intent.Sensitive(SensitiveAction.PURCHASE), CommandParser.parse("compre um fone"))
        assertEquals(Intent.Sensitive(SensitiveAction.DELETE_FILE), CommandParser.parse("apague todos os arquivos da pasta"))
    }

    @Test fun normalChat() {
        assertTrue(CommandParser.parse("explique o que é um buraco negro") is Intent.Chat)
    }
}
