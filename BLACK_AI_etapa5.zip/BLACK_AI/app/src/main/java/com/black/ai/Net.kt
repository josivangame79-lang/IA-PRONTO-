package com.black.ai

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class NetState { OFFLINE, MOBILE, WIFI }

/** Detecta a conexão em tempo real (online/offline e Wi-Fi/dados móveis). */
class ConnectivityMonitor(ctx: Context) {
    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val _state = MutableStateFlow(current())
    val state: StateFlow<NetState> = _state

    private fun current(): NetState {
        val n = cm.activeNetwork ?: return NetState.OFFLINE
        val c = cm.getNetworkCapabilities(n) ?: return NetState.OFFLINE
        if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return NetState.OFFLINE
        val wifi = c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        return if (wifi) NetState.WIFI else NetState.MOBILE
    }

    init {
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { _state.value = current() }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { _state.value = current() }
            override fun onLost(network: Network) { _state.value = NetState.OFFLINE }
        })
    }
}

/** Configurações. A chave de API fica em armazenamento criptografado (Android Keystore). */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("black", Context.MODE_PRIVATE)
    private val secure = EncryptedSharedPreferences.create(
        ctx,
        "black_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var serverUrl: String
        get() = p.getString("server_url", "") ?: ""
        set(v) { p.edit().putString("server_url", v.trim()).apply() }

    var model: String
        get() = p.getString("model", "default") ?: "default"
        set(v) { p.edit().putString("model", v.trim().ifBlank { "default" }).apply() }

    var apiKey: String
        get() = secure.getString("api_key", "") ?: ""
        set(v) { secure.edit().putString("api_key", v.trim()).apply() }

    var activeModel: String
        get() = p.getString("active_model", "") ?: ""
        set(v) { p.edit().putString("active_model", v).apply() }

    val preferLocal = MutableStateFlow(p.getBoolean("prefer_local", false))
    fun setPreferLocal(v: Boolean) { p.edit().putBoolean("prefer_local", v).apply(); preferLocal.value = v }

    val forceOffline = MutableStateFlow(p.getBoolean("force_offline", false))
    fun setForceOffline(v: Boolean) { p.edit().putBoolean("force_offline", v).apply(); forceOffline.value = v }

    fun getDisabledTools(): Set<String> = p.getStringSet("disabled_tools", emptySet()) ?: emptySet()
    fun saveDisabledTools(s: Set<String>) { p.edit().putStringSet("disabled_tools", HashSet(s)).apply() }
}
