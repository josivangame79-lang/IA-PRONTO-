package com.black.ai

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** Banco local (Room/SQLite): histórico, memória de longo prazo e registro de ações. */

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "assistant"
    val content: String,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // "LONG" (curto prazo = histórico de mensagens)
    val text: String,
    val source: String,
    val ts: Long = System.currentTimeMillis()
)

@Entity(tableName = "action_log")
data class ActionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val agent: String,
    val action: String,
    val status: String,
    val ts: Long = System.currentTimeMillis()
)

@Dao
interface BlackDao {
    @Insert suspend fun insertMessage(m: MessageEntity): Long
    @Query("SELECT * FROM messages ORDER BY ts ASC, id ASC") fun messages(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages ORDER BY ts DESC, id DESC LIMIT :n") suspend fun lastMessages(n: Int): List<MessageEntity>

    @Insert suspend fun insertMemory(m: MemoryEntity): Long
    @Query("SELECT * FROM memories ORDER BY ts DESC") fun memories(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memories ORDER BY ts DESC") suspend fun allMemories(): List<MemoryEntity>
    @Query("SELECT COUNT(*) FROM memories WHERE text = :text") suspend fun countMemoryText(text: String): Int
    @Query("SELECT * FROM memories WHERE text LIKE '%' || :q || '%' ORDER BY ts DESC LIMIT :n")
    suspend fun searchMemory(q: String, n: Int): List<MemoryEntity>
    @Query("DELETE FROM memories WHERE id = :id") suspend fun deleteMemory(id: Long)

    @Insert suspend fun insertLog(l: ActionLogEntity)
    @Query("SELECT * FROM action_log ORDER BY ts DESC, id DESC LIMIT 200") fun log(): Flow<List<ActionLogEntity>>
}

@Database(
    entities = [MessageEntity::class, MemoryEntity::class, ActionLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BlackDb : RoomDatabase() {
    abstract fun dao(): BlackDao
}
