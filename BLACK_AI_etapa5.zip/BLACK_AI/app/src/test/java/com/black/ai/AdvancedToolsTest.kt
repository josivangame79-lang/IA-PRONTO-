package com.black.ai

import org.junit.Assert.*
import org.junit.Test

class AdvancedToolsTest {
    @Test fun calculatorHonorsPrecedenceAndParentheses() {
        assertEquals(60.0, SafeCalculator.evaluate("(12 + 8) * 3"), 0.0001)
        assertEquals(14.0, SafeCalculator.evaluate("2 + 3 * 4"), 0.0001)
        assertEquals(512.0, SafeCalculator.evaluate("2^3^2"), 0.0001)
    }
    @Test fun calculatorRejectsDivisionByZeroAndTrailingInput() {
        assertThrows(IllegalArgumentException::class.java) { SafeCalculator.evaluate("4/0") }
        assertThrows(IllegalArgumentException::class.java) { SafeCalculator.evaluate("2 + xyz") }
    }
    @Test fun codeInspectorFindsCommonRisks() {
        val result = CodeInspector.inspect("val api_key = \"secret-value\"\nval x = thing!!")
        assertTrue(result.contains("segredo"))
        assertTrue(result.contains("!!"))
    }
    @Test fun csvEscapesQuotesAndCommas() {
        assertEquals("\"a,b\",\"ele disse \"\"oi\"\"\"", CsvExporter.fromRows(listOf(listOf("a,b", "ele disse \"oi\""))))
    }
}
