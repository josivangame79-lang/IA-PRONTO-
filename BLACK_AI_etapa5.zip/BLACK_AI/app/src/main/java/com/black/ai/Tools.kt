package com.black.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class ToolInfo(
    val id: String,
    val name: String,
    val category: String,
    val implemented: Boolean,
    val note: String = ""
)

/** Central de ferramentas: lista honesta do que existe e do que ainda é planejado; ativar/desativar. */
class ToolRegistry(private val settings: Settings) {
    val all: List<ToolInfo> = listOf(
        ToolInfo("memory", "Memória contextual local", "Memória", true, "Recuperação ranqueada por relevância e recência; dados permanecem no aparelho"),
        ToolInfo("backup", "Backup e sincronização por arquivo", "Memória", true, "Exportar/importar memórias em JSON usando o seletor do Android"),
        ToolInfo("datetime", "Data e hora", "Pessoal", true),
        ToolInfo("remote_llm", "Modelo no servidor próprio (API compatível OpenAI)", "IA", true, "Configure em Config"),
        ToolInfo("local_llm", "Modelo local offline (LiteRT-LM)", "IA", true, "Importe um .litertlm em Config > Modelos"),
        ToolInfo("rag", "Recuperação contextual (RAG leve)", "IA", true, "Busca lexical ranqueada local; embeddings vetoriais ficam para etapa futura"),
        ToolInfo("web_search", "Pesquisa na web", "Pesquisa", true, "DuckDuckGo HTML; requer internet"),
        ToolInfo("scholar", "Pesquisa científica/acadêmica", "Pesquisa", true, "Crossref; metadados e DOI, requer internet"),
        ToolInfo("code", "Análise estática de código", "Programação", true, "Detecta padrões comuns; não executa código arbitrário"),
        ToolInfo("github", "Busca de repositórios GitHub", "Programação", true, "Busca pública sem token; operações de escrita não habilitadas"),
        ToolInfo("stt", "Reconhecimento de fala", "Voz", true, "Usa o reconhecedor de fala disponível no Android; pode exigir internet conforme o aparelho"),
        ToolInfo("tts", "Síntese de voz", "Voz", true, "Usa o mecanismo Text-to-Speech instalado no Android"),
        ToolInfo("image_analysis", "Análise de imagens", "Multimídia", false, "Depende de endpoint de visão compatível e seleção explícita de imagem"),
        ToolInfo("image_gen", "Geração de imagens", "Multimídia", false, "Depende de provedor/modelo de geração de imagens"),
        ToolInfo("docs", "Exportação de texto e CSV", "Documentos", true, "Salvar pelo seletor Android; PDF/DOCX/XLSX avançados ficam para integração futura"),
        ToolInfo("calendar", "Criar evento no calendário", "Pessoal", true, "Abre o calendário do Android para revisão e confirmação"),
        ToolInfo("files", "Leitura e gravação de arquivos escolhidos", "Pessoal", true, "Acesso somente aos arquivos selecionados pelo usuário"),
        ToolInfo("translate", "Tradução online", "Avançadas", true, "MyMemory; requer internet e revisão humana"),
        ToolInfo("data_analysis", "Calculadora e análise estática", "Avançadas", true, "Calculadora segura e verificações simples de código")
    )

    private val _disabled = MutableStateFlow(settings.getDisabledTools())
    val disabled: StateFlow<Set<String>> = _disabled

    fun isEnabled(id: String) = id !in _disabled.value

    fun setEnabled(id: String, enabled: Boolean) {
        val next = if (enabled) _disabled.value - id else _disabled.value + id
        _disabled.value = next
        settings.saveDisabledTools(next)
    }
}
