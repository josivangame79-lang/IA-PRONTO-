package com.black.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRankerTest {
    @Test fun ranksRelevantMemoryFirst() {
        val rows = listOf(
            MemoryEntity(id = 1, kind = "LONG", text = "Gosto de jogos de corrida", source = "teste", ts = 1000),
            MemoryEntity(id = 2, kind = "LONG", text = "Meu projeto se chama BLACK AI e terá modo offline", source = "teste", ts = 1000)
        )
        val result = MemoryRanker.rank("Como está meu projeto BLACK AI offline?", rows, now = 1000)
        assertEquals(2L, result.first().id)
    }

    @Test fun returnsEmptyWhenNoUsefulTermsOverlap() {
        val rows = listOf(MemoryEntity(id = 1, kind = "LONG", text = "Gosto de jogos", source = "teste", ts = 1000))
        assertTrue(MemoryRanker.rank("astronomia telescópio", rows, now = 1000).isEmpty())
    }
}
