package com.black.ai

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BlackBg = Color(0xFF000000)
val BlackSurface = Color(0xFF0A0F1C)
val BlackCard = Color(0xFF111A2E)
val BlueMain = Color(0xFF7C3AED)
val BlueCyan = Color(0xFFB388FF)
val AlertRed = Color(0xFFFF4D4D)
val OkGreen = Color(0xFF3DDC84)

@Composable
fun BlackTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = BlueMain,
            secondary = BlueCyan,
            background = BlackBg,
            surface = BlackSurface,
            surfaceVariant = BlackCard,
            onPrimary = Color.White,
            onBackground = Color(0xFFE6ECFF),
            onSurface = Color(0xFFE6ECFF),
            onSurfaceVariant = Color(0xFFB7C3E6),
            error = AlertRed
        ),
        content = content
    )
}
