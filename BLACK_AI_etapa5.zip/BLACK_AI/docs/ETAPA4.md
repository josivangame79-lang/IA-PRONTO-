# BLACK AI — Etapa 4 (memória contextual, voz e backup local)

## Incluído nesta etapa

- **BLACK LEARN:** agente identificado como ativo para aprendizado por memória explícita. O usuário pede para guardar informações; o app não altera nem treina os pesos do modelo.
- **BLACK MEMORY / RAG leve:** recuperação local de memórias com pontuação por sobreposição de termos, raridade dos termos (IDF), correspondência de frase e recência. As memórias relevantes são anexadas ao contexto do chat.
- **BLACK VOICE:** botão de microfone no chat, com solicitação de permissão `RECORD_AUDIO`, reconhecimento em `pt-BR` pelo serviço de fala disponível no Android e leitura das respostas pelo Text-to-Speech.
- **Backup local:** exportação e importação de memórias em JSON pelo seletor de documentos do Android. Importação ignora textos já existentes.
- **Testes JVM:** ranking da memória contextual.

## Privacidade e limites

- A busca contextual é local e não usa embeddings neurais. É uma recuperação lexical melhorada, não uma busca semântica vetorial completa.
- O reconhecimento de fala depende de um serviço de reconhecimento instalado; alguns aparelhos/serviços podem usar internet. A entrada por voz não envia automaticamente a mensagem: o usuário revisa e toca em Enviar.
- A leitura de voz usa o mecanismo TTS do Android e a voz instalada/configurada no aparelho.
- O backup contém informações pessoais em texto JSON. O usuário escolhe onde salvar e deve proteger o arquivo. A importação não substitui nem apaga as memórias atuais.
- Não existe sincronização automática entre aparelhos ou nuvem nesta etapa; o backup manual permite transportar memórias entre instalações.
- O BLACK LEARN não faz fine-tuning nem aprende sozinho com a web. A aprendizagem persistente ocorre por memórias explícitas do usuário.

## Como testar

1. Abra Chat e toque no microfone; conceda permissão e fale uma frase. Revise o texto reconhecido antes de enviar.
2. Toque em **Ouvir** em uma resposta para testar o TTS.
3. Envie `lembre que meu projeto se chama BLACK AI`.
4. Pergunte `o que você sabe sobre meu projeto BLACK AI` para testar a recuperação contextual.
5. Em Memória, exporte `black-ai-memories.json`; depois importe o arquivo. Itens já existentes devem ser ignorados.
6. Execute `./gradlew testDebugUnitTest` e compile o APK em Android Studio ou GitHub Actions.

## Versão

- `versionCode = 4`
- `versionName = 0.4.0`

**Status honesto:** o código foi alterado e empacotado, mas precisa de build e teste em aparelho Android. Não afirmar que voz, LiteRT-LM ou APK estão validados até executar esses testes.
