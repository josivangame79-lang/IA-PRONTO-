package com.black.ai

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

private class FakeEngine(override val name: String, private val ready: Boolean, private val fails: Boolean = false) : LlmEngine {
    override suspend fun isReady() = ready
    override suspend fun chat(msgs: List<ChatMsg>): String =
        if (fails) throw RuntimeException("boom") else "ok-$name"
}

class LlmRouterTest {
    private val msgs = listOf(ChatMsg("user", "oi"))

    private fun router(online: Boolean, preferLocal: Boolean, local: LlmEngine, remote: LlmEngine) =
        LlmRouter({ online }, { preferLocal }, local, remote)

    @Test fun onlineUsesRemote() = runBlocking {
        val r = router(true, false, FakeEngine("local", true), FakeEngine("remote", true))
        assertEquals("ok-remote", r.chat(msgs))
        assertEquals("remote", r.lastUsed.value)
    }

    @Test fun offlineUsesLocal() = runBlocking {
        val r = router(false, false, FakeEngine("local", true), FakeEngine("remote", true))
        assertEquals("ok-local", r.chat(msgs))
    }

    @Test fun remoteFailureFallsBackToLocal() = runBlocking {
        val r = router(true, false, FakeEngine("local", true), FakeEngine("remote", true, fails = true))
        assertEquals("ok-local", r.chat(msgs))
        assertEquals("local", r.lastUsed.value)
    }

    @Test fun preferLocalWinsWhenOnline() = runBlocking {
        val r = router(true, true, FakeEngine("local", true), FakeEngine("remote", true))
        assertEquals("ok-local", r.chat(msgs))
    }

    @Test fun noEngineExplainsWhy() = runBlocking {
        val r = router(false, false, FakeEngine("local", false), FakeEngine("remote", true))
        try {
            r.chat(msgs)
            fail("deveria lançar NoEngineException")
        } catch (e: NoEngineException) {
            assertTrue(e.message!!.contains("sem conexão"))
            assertTrue(e.message!!.contains("nenhum modelo local ativo"))
        }
    }
}
