package com.black.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class WebResult(
    val title: String,
    val url: String,
    val snippet: String,
    val source: String
)

/**
 * Pesquisa pública sem chave de API. Pesquisa geral usa DuckDuckGo HTML;
 * pesquisa acadêmica usa a API pública Crossref. Resultados sempre incluem URL.
 */
class WebResearch {
    suspend fun search(query: String, academic: Boolean = false, limit: Int = 5): List<WebResult> =
        withContext(Dispatchers.IO) {
            require(query.isNotBlank()) { "Digite o que deseja pesquisar." }
            if (academic) searchCrossref(query, limit.coerceIn(1, 8))
            else searchDuckDuckGo(query, limit.coerceIn(1, 8))
        }

    private fun connection(url: String): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 18_000
            setRequestProperty("User-Agent", "BLACK-AI-Android/0.3 (research assistant)")
            setRequestProperty("Accept", "text/html,application/json")
        }
    }

    private fun searchDuckDuckGo(query: String, limit: Int): List<WebResult> {
        val q = URLEncoder.encode(query, "UTF-8")
        val conn = connection("https://html.duckduckgo.com/html/?q=$q")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Pesquisa web respondeu HTTP $code")
            val html = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val blocks = Regex(
                """(?is)<div[^>]*class=["'][^"']*(?:^|\s)result(?:\s|$)[^"']*["'][^>]*>(.*?)(?=<div[^>]*class=["'][^"']*(?:^|\s)result(?:\s|$)[^"']*["']|</html>)"""
            ).findAll(html)
            val results = mutableListOf<WebResult>()
            for (block in blocks) {
                if (results.size >= limit) break
                val chunk = block.value
                val linkMatch = Regex("""(?is)<a[^>]*class=["'][^"']*result__a[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>(.*?)</a>""")
                    .find(chunk) ?: continue
                val rawUrl = decodeEntities(linkMatch.groupValues[1])
                val target = if (rawUrl.contains("uddg=")) {
                    runCatching {
                        val encoded = Regex("[?&]uddg=([^&]+)").find(rawUrl)?.groupValues?.get(1)
                        if (encoded != null) java.net.URLDecoder.decode(encoded, "UTF-8") else rawUrl
                    }.getOrDefault(rawUrl)
                } else rawUrl
                if (!target.startsWith("http")) continue
                val title = cleanHtml(linkMatch.groupValues[2]).ifBlank { target }
                val snippet = Regex("""(?is)<a[^>]*class=["'][^"']*result__snippet[^"']*["'][^>]*>(.*?)</a>|<td[^>]*class=["'][^"']*result__snippet[^"']*["'][^>]*>(.*?)</td>""")
                    .find(chunk)?.let { cleanHtml(it.groupValues[1].ifBlank { it.groupValues[2] }) }.orEmpty()
                results += WebResult(title.take(180), target, snippet.take(500), "DuckDuckGo")
            }
            if (results.isEmpty()) throw IOException("A pesquisa não retornou resultados. Tente outra expressão.")
            results
        } finally {
            conn.disconnect()
        }
    }

    private fun searchCrossref(query: String, limit: Int): List<WebResult> {
        val q = URLEncoder.encode(query, "UTF-8")
        val conn = connection("https://api.crossref.org/works?query.bibliographic=$q&rows=$limit")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Pesquisa acadêmica respondeu HTTP $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val items = JSONObject(body).getJSONObject("message").getJSONArray("items")
            val out = mutableListOf<WebResult>()
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val titleArray = item.optJSONArray("title")
                val title = titleArray?.optString(0).orEmpty()
                val doi = item.optString("DOI")
                if (title.isBlank() || doi.isBlank()) continue
                val authors = item.optJSONArray("author")
                val author = authors?.optJSONObject(0)?.optString("family").orEmpty()
                val year = item.optJSONObject("published")?.optJSONArray("date-parts")
                    ?.optJSONArray(0)?.optInt(0, 0) ?: 0
                val snippet = buildString {
                    if (author.isNotBlank()) append(author)
                    if (year > 0) append(if (isNotEmpty()) " · $year" else year.toString())
                    val abstract = item.optString("abstract").take(350)
                    if (abstract.isNotBlank()) append(" · ").append(cleanHtml(abstract))
                }
                out += WebResult(title, "https://doi.org/$doi", snippet, "Crossref")
            }
            if (out.isEmpty()) throw IOException("Nenhum artigo acadêmico foi encontrado.")
            out
        } finally {
            conn.disconnect()
        }
    }

    private fun cleanHtml(value: String): String =
        decodeEntities(value.replace(Regex("(?is)<script.*?</script>|<style.*?</style>"), " ")
            .replace(Regex("(?s)<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim())

    private fun decodeEntities(value: String): String = value
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
        .replace("&#x27;", "'").replace("&ndash;", "–").replace("&mdash;", "—")
}

enum class BlackTask { RESEARCH, SCHOLAR, PLANNER, ANALYST, CHAT }

object AgentRouter {
    fun route(text: String): BlackTask {
        val s = text.lowercase()
        return when {
            Regex("""\b(pesquisa científica|pesquise artigos|artigos científicos|fontes acadêmicas|estudos científicos)\b""").containsMatchIn(s) -> BlackTask.SCHOLAR
            Regex("""\b(pesquise|pesquisa|procure na web|busque na internet|fontes atuais|notícias sobre|o que aconteceu recentemente)\b""").containsMatchIn(s) -> BlackTask.RESEARCH
            Regex("""\b(planeje|planejar|crie um plano|monte um plano|organize|cronograma|etapas para)\b""").containsMatchIn(s) -> BlackTask.PLANNER
            Regex("""\b(analise|analisar|compare|comparar|avalie|avaliar|verifique|verificar|pontos fortes|pontos fracos)\b""").containsMatchIn(s) -> BlackTask.ANALYST
            else -> BlackTask.CHAT
        }
    }
}

class PlanningAgent(private val llm: LlmRouter) {
    suspend fun run(task: String, history: List<ChatMsg>): String {
        val system = ChatMsg(
            "system",
            "Você é BLACK PLANNER. Transforme o pedido em plano prático, realista e organizado em etapas numeradas. " +
                "Inclua objetivo, pré-requisitos, sequência, prazo estimado quando possível, riscos e como verificar conclusão. " +
                "Não execute ações nem invente dados. Responda em português do Brasil."
        )
        return try { llm.chat(listOf(system) + history.dropLast(1) + ChatMsg("user", task)) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) {
                "Plano inicial para: $task\n\n1. Definir o objetivo e o resultado esperado.\n2. Reunir recursos e informações necessárias.\n3. Dividir o trabalho em tarefas pequenas.\n4. Executar uma tarefa por vez e revisar o progresso.\n5. Testar o resultado e corrigir problemas.\n\nEste é um plano-base; faltam detalhes para estimar prazos e recursos."
            }
    }
}

class AnalystAgent(private val llm: LlmRouter) {
    suspend fun run(task: String, history: List<ChatMsg>): String {
        val system = ChatMsg(
            "system",
            "Você é BLACK ANALYST. Analise com rigor o material fornecido. Separe fatos, hipóteses e incertezas; " +
                "compare critérios, mostre vantagens, limitações, riscos e uma conclusão proporcional às evidências. " +
                "Não invente fontes, números ou verificações. Se faltar material, diga exatamente o que falta. " +
                "Responda em português do Brasil."
        )
        return try { llm.chat(listOf(system) + history.dropLast(1) + ChatMsg("user", task)) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { "Análise estruturada:\n• Objetivo: identifique o que precisa ser avaliado.\n• Evidências: reúna dados verificáveis.\n• Comparação: use os mesmos critérios para todas as opções.\n• Limitações: registre informações ausentes e possíveis vieses.\n• Conclusão: só decida na medida em que as evidências permitirem.\n\nPara uma análise específica, configure um motor de IA e forneça o material." }
    }
}

class ResearchAgent(private val web: WebResearch, private val llm: LlmRouter) {
    suspend fun run(query: String, academic: Boolean, history: List<ChatMsg>): String {
        val results = web.search(query, academic, 6)
        val sourceText = results.mapIndexed { i, r ->
            "${i + 1}. ${r.title}\nFonte: ${r.source}\nURL: ${r.url}\nResumo: ${r.snippet.ifBlank { "Resumo não fornecido pelo mecanismo." }}"
        }.joinToString("\n\n")
        val system = ChatMsg(
            "system",
            "Você é BLACK RESEARCH. Sintetize apenas o conteúdo e os metadados fornecidos. " +
                "Não afirme que abriu ou verificou páginas que não foram abertas. Diferencie resultados de busca de fatos confirmados. " +
                "Aponte divergências e lacunas. Inclua as URLs das fontes no final. Responda em português do Brasil."
        )
        val prompt = ChatMsg("user", "Pedido: $query\n\nResultados encontrados:\n$sourceText\n\nFaça uma síntese útil e indique as limitações.")
        val synthesis = try { llm.chat(listOf(system) + history.dropLast(1) + prompt) }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { "Encontrei estes resultados. A síntese por IA não foi possível porque nenhum motor respondeu." }
        return "$synthesis\n\nFontes consultadas:\n$sourceText"
    }
}
