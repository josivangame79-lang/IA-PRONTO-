# BLACK AI — Etapa 5 (toolbox avançada, arquivos e conectores)

Assistente pessoal Android: Kotlin + Jetpack Compose, interface preta e roxa, português do Brasil.
Aprendizado HÍBRIDO · Ferramentas ADVANCED · Autonomia CONTROLLED · Online + Offline.

## Etapa 5 — BLACK TOOLBOX
- Calculadora segura com parser matemático limitado.
- BLACK CODE para análise estática; não executa código arbitrário.
- Busca de repositórios públicos pelo GitHub REST API.
- Tradução online pt → en pelo MyMemory.
- Leitura de arquivos de texto escolhidos pelo usuário e exportação TXT/CSV.
- Criação de evento via app de calendário e compartilhamento pelo seletor Android.
- Veja `docs/ETAPA5.md` para limites, privacidade e funções ainda planejadas.

## Etapa 4 — memória, voz e backup
- BLACK LEARN para aprendizado por memória explícita do usuário (não treina pesos do modelo).
- Recuperação contextual local ranqueada por relevância, raridade dos termos e recência; as memórias relevantes entram no contexto do chat.
- BLACK VOICE: reconhecimento de fala em pt-BR pelo serviço disponível no Android e leitura de respostas por Text-to-Speech.
- Backup manual de memórias em JSON, com exportação/importação pelo seletor do Android e prevenção de duplicatas.
- Testes JVM para o ranking da memória.

## O que foi incorporado

### Etapa 1 — núcleo
- BLACK CORE: recebe mensagens e encaminha tarefas.
- Room: histórico, memória de longo prazo e log de ações.
- Detector de conectividade e configuração online/offline.
- BLACK MEMORY e BLACK SECURITY.
- Autorizações explícitas para ações sensíveis e botão PARAR.
- Chat, agentes, ferramentas, memória e configurações.

### Etapa 2 — IA local
- LiteRT-LM para executar modelos `.litertlm` localmente (CPU/arm64).
- Importação, seleção e remoção de modelos em Config > Modelos.
- Roteador online/offline, opção de preferir modelo local e cancelamento da geração.
- Descarregamento do modelo ao colocar o app em segundo plano.

### Etapa 3 — pesquisa e agentes
| Agente/ferramenta | Implementação |
|---|---|
| BLACK RESEARCH | Pesquisa geral pelo DuckDuckGo HTML; retorna títulos, trechos e URLs |
| Pesquisa acadêmica | Consulta a API pública Crossref; retorna metadados e DOI |
| BLACK PLANNER | Envia pedidos de planejamento ao motor de IA; tem plano-base caso o motor não responda |
| BLACK ANALYST | Analisa material com instruções de separar fatos, hipóteses, riscos e incertezas; tem estrutura-base de reserva |
| BLACK CORE | Detecta o tipo de pedido e encaminha para o agente adequado |
| Central de ferramentas | Pesquisa web e acadêmica aparecem como disponíveis e podem ser ativadas/desativadas |

### Etapa 4 — memória contextual, voz e backup
- BLACK LEARN: aprendizagem por memórias explícitas do usuário, sem treinar pesos do modelo.
- Memória contextual local: ranking por termos relevantes, raridade e recência; resultados são adicionados ao contexto do chat.
- BLACK VOICE: entrada de fala em pt-BR com permissão de microfone e leitura de respostas por TTS.
- Backup/importação manual de memórias em JSON pelo seletor de arquivos do Android.
- Detalhes e testes: `docs/ETAPA4.md`.

## Como usar a Etapa 3
- `Pesquise na web sobre energia solar` → BLACK RESEARCH.
- `Faça uma pesquisa científica sobre energia solar` → Crossref.
- `Crie um plano para estudar matemática` → BLACK PLANNER.
- `Compare estas duas opções: ...` → BLACK ANALYST.

A pesquisa web e acadêmica exige internet e não funciona quando "Forçar modo offline" está ativado. O app envia a consulta para DuckDuckGo ou Crossref. A pesquisa geral usa resultados/snippets e links; não afirma ter lido páginas completas. Abra as URLs para conferir o conteúdo original. Crossref fornece metadados bibliográficos e DOI, não garante acesso ao texto integral.

Planner e Analyst usam o motor de IA selecionado (servidor próprio ou modelo local). Sem motor configurado, entregam uma estrutura-base e informam a limitação. A pesquisa pode continuar a localizar fontes mesmo se a síntese por IA não estiver disponível.

## Limites e status honesto
**Esta versão foi editada e empacotada, mas não foi compilada nem executada em um aparelho nesta sessão.** O ambiente não dispõe de Android SDK/Gradle configurado para validar o APK. A dependência LiteRT-LM e o carregamento de modelo real continuam precisando de teste em aparelho arm64.

- DuckDuckGo HTML pode mudar a estrutura da página ou limitar requisições; se isso ocorrer, a pesquisa pode falhar e mostrar um erro.
- A pesquisa web usa trechos e links de resultados, não leitura integral/crawling dos sites.
- Crossref é uma fonte de metadados acadêmicos; não é uma busca em todas as bases científicas.
- Os agentes não treinam nem alteram os pesos do modelo. "Aprendizado" continua sendo memória explícita do usuário, não fine-tuning.
- Ações sensíveis continuam exigindo autorização; os agentes não têm permissão para executar compras, enviar mensagens ou excluir arquivos.
- PARAR cancela a tarefa Kotlin; uma requisição HTTP já iniciada pode demorar até o timeout para encerrar.

## Gerar APK
1. Abra a pasta `BLACK_AI` no Android Studio e aguarde a sincronização do Gradle.
2. Execute os testes JVM: `./gradlew testDebugUnitTest` (ou pelo painel Gradle).
3. Use **Build > Build APK(s)**.
4. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

Também existe o workflow `.github/workflows/build-apk.yml` para compilar e publicar o APK como artefato no GitHub Actions. O projeto não inclui `gradle-wrapper.jar`; se necessário, gere o wrapper no Android Studio ou configure o Gradle no repositório.

## Configuração de IA
Em Config > Geral, informe um servidor compatível com OpenAI (`/v1/chat/completions`) e o nome do modelo. Para modo offline, importe um `.litertlm` em Config > Modelos. A chave de API é guardada no armazenamento criptografado do Android.

## Próximas etapas
Etapa 6: evolução controlada, testes isolados, versões, rollback e backup.
Etapa 7: análise/geração de imagens e formatos de documentos avançados, após escolher provedores e bibliotecas.
