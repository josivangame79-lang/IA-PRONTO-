package com.black.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AgentInfo(
    val id: String,
    val name: String,
    val role: String,
    val implemented: Boolean,
    val note: String = ""
)

interface Agent { val info: AgentInfo }

/** Agente ainda não implementado: aparece na lista com status PLANEJADO, nunca finge funcionar. */
class PlannedAgent(override val info: AgentInfo) : Agent

class MemoryAgent(private val dao: BlackDao, private val logger: ActionLogger) : Agent {
    override val info = AgentInfo("memory", "BLACK MEMORY", "Memória de longo prazo e recuperação contextual", true, "Busca local ranqueada por relevância, sem enviar memórias à nuvem")

    suspend fun remember(text: String) {
        dao.insertMemory(MemoryEntity(kind = "LONG", text = text, source = "usuário"))
        logger.log(info.name, "Memória salva: ${text.take(80)}", "OK")
    }

    suspend fun recall(query: String, n: Int = 5): List<MemoryEntity> =
        MemoryRanker.rank(query, dao.allMemories()).take(n)

    /** Recuperação contextual local: ranking lexical ponderado por raridade e recência. */
    suspend fun relevantFor(input: String): List<MemoryEntity> =
        MemoryRanker.rank(input, dao.allMemories()).take(5)
}

class SecurityAgent(private val perms: PermissionManager) : Agent {
    override val info = AgentInfo("security", "BLACK SECURITY", "Segurança e autorizações", true, "Porta de autorização para ações sensíveis; antivírus/verificação de módulos: etapa 6")
    suspend fun gate(action: SensitiveAction, detail: String): Boolean = perms.request(info.name, action, detail)
}

/** BLACK AI CORE: recebe a mensagem, decide a rota, aplica as permissões e responde. */
class BlackCore(
    private val scope: CoroutineScope,
    private val dao: BlackDao,
    private val llm: LlmRouter,
    private val memory: MemoryAgent,
    private val security: SecurityAgent,
    private val perms: PermissionManager,
    private val tools: ToolRegistry,
    private val logger: ActionLogger,
    private val research: ResearchAgent,
    private val planner: PlanningAgent,
    private val analyst: AnalystAgent,
    private val canResearchOnline: () -> Boolean
) {
    private val coreName = "BLACK CORE"

    val agents: List<Agent> = listOf(
        memory,
        security,
        object : Agent { override val info = AgentInfo("research", "BLACK RESEARCH", "Pesquisa web e síntese de fontes", true, "DuckDuckGo; exige internet") },
        object : Agent { override val info = AgentInfo("learn", "BLACK LEARN", "Aprendizado por memória explícita e recuperação contextual", true, "Aprende somente quando você pede para lembrar; não treina pesos do modelo") },
        object : Agent { override val info = AgentInfo("code", "BLACK CODE", "Análise estática e apoio à programação", true, "Analisa código sem executá-lo; busca repositórios públicos no GitHub") },
        PlannedAgent(AgentInfo("creative", "BLACK CREATIVE", "Análise e geração de imagens", false, "Requer provedor multimodal configurado; não habilitado nesta versão")),
        object : Agent { override val info = AgentInfo("voice", "BLACK VOICE", "Entrada e saída por voz", true, "Reconhecimento e leitura dependem dos serviços de voz do Android") },
        object : Agent { override val info = AgentInfo("planner", "BLACK PLANNER", "Planejamento e decomposição de tarefas", true, "Usa o motor de IA configurado; possui plano-base de reserva") },
        object : Agent { override val info = AgentInfo("analyst", "BLACK ANALYST", "Análise crítica e comparação", true, "Separa fatos, hipóteses e incertezas") }
    )

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private var job: Job? = null

    fun submit(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _busy.value) return
        _busy.value = true
        job = scope.launch {
            try {
                process(t)
            } catch (e: CancellationException) {
                logger.log(coreName, "Tarefa interrompida pelo usuário", "INTERROMPIDO")
                throw e
            } catch (e: Exception) {
                reply("⚠️ ${e.message ?: e.javaClass.simpleName}")
            } finally {
                _busy.value = false
            }
        }
    }

    /** Botão PARAR: nega autorizações pendentes e cancela a tarefa em andamento. */
    fun stop() {
        perms.denyAll()
        job?.cancel()
    }

    private suspend fun reply(text: String) {
        dao.insertMessage(MessageEntity(role = "assistant", content = text))
    }

    private suspend fun process(text: String) {
        dao.insertMessage(MessageEntity(role = "user", content = text))
        when (val intent = CommandParser.parse(text)) {
            is Intent.Sensitive -> {
                val ok = security.gate(intent.action, text)
                reply(
                    if (ok) "Autorização registrada (${intent.action.label}). Mas ainda não existe ferramenta capaz de executar isso (planejada para etapas futuras). Nada foi feito."
                    else "Ação negada. Nada foi feito."
                )
            }
            is Intent.Remember -> {
                if (!tools.isEnabled("memory")) { reply("A ferramenta de memória está desativada na Central de ferramentas."); return }
                memory.remember(intent.text)
                reply("Guardei na memória de longo prazo: \"${intent.text}\"")
            }
            is Intent.Recall -> {
                if (!tools.isEnabled("memory")) { reply("A ferramenta de memória está desativada na Central de ferramentas."); return }
                val found = memory.recall(intent.query)
                reply(
                    if (found.isEmpty()) "Não encontrei nada na memória sobre \"${intent.query}\"."
                    else "Encontrei na memória:\n" + found.joinToString("\n") { "• ${it.text}" }
                )
            }
            Intent.TimeQuery -> {
                if (!tools.isEnabled("datetime")) { reply("A ferramenta de data e hora está desativada."); return }
                val fmt = SimpleDateFormat("EEEE, dd/MM/yyyy 'às' HH:mm", Locale("pt", "BR"))
                reply("Agora: ${fmt.format(Date())}")
            }
            Intent.Chat -> dispatch(text)
        }
    }



    private suspend fun dispatch(text: String) {
        val history = dao.lastMessages(12).reversed().map { ChatMsg(it.role, it.content) }
        when (AgentRouter.route(text)) {
            BlackTask.RESEARCH -> {
                if (!tools.isEnabled("web_search")) { reply("A ferramenta de pesquisa web está desativada."); return }
                if (!canResearchOnline()) {
                    reply("A pesquisa na web precisa de internet. O BLACK continua disponível no modo offline para tarefas locais.")
                    return
                }
                logger.log("BLACK RESEARCH", "Pesquisa: ${text.take(100)}", "INICIADA")
                reply(research.run(text, false, history))
                logger.log("BLACK RESEARCH", "Pesquisa concluída", "OK")
            }
            BlackTask.SCHOLAR -> {
                if (!tools.isEnabled("scholar")) { reply("A pesquisa acadêmica está desativada."); return }
                if (!canResearchOnline()) {
                    reply("A pesquisa acadêmica precisa de internet.")
                    return
                }
                logger.log("BLACK RESEARCH", "Pesquisa acadêmica: ${text.take(100)}", "INICIADA")
                reply(research.run(text, true, history))
                logger.log("BLACK RESEARCH", "Pesquisa acadêmica concluída", "OK")
            }
            BlackTask.PLANNER -> {
                logger.log("BLACK PLANNER", "Planejamento: ${text.take(100)}", "INICIADO")
                reply(planner.run(text, history))
                logger.log("BLACK PLANNER", "Planejamento concluído", "OK")
            }
            BlackTask.ANALYST -> {
                logger.log("BLACK ANALYST", "Análise: ${text.take(100)}", "INICIADA")
                reply(analyst.run(text, history))
                logger.log("BLACK ANALYST", "Análise concluída", "OK")
            }
            BlackTask.CHAT -> chat(text)
        }
    }


    private suspend fun chat(text: String) {
        val system = buildString {
            append("Você é o BLACK, assistente pessoal em português do Brasil. Seja direto e honesto. ")
            append("Se não souber, diga que não sabe. Nunca finja ter executado ações ou ferramentas que você não possui.")
            if (tools.isEnabled("memory")) {
                val mem = memory.relevantFor(text)
                if (mem.isNotEmpty()) {
                    append("\n\nMemórias do usuário que podem ser relevantes:\n")
                    mem.forEach { append("- ${it.text}\n") }
                }
            }
        }
        val history = dao.lastMessages(12).reversed().map { ChatMsg(it.role, it.content) }
        val answer = llm.chat(listOf(ChatMsg("system", system)) + history)
        reply(answer)
        logger.log(coreName, "Resposta gerada por: ${llm.lastUsed.value}", "OK")
    }
}
