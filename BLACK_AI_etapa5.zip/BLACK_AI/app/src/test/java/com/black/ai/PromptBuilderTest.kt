package com.black.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PromptBuilderTest {
    @Test fun keepsSystemHistoryAndCurrentMessageInOrder() {
        val p = PromptBuilder.flatten(listOf(
            ChatMsg("system", "SISTEMA"),
            ChatMsg("user", "primeira"),
            ChatMsg("assistant", "resposta"),
            ChatMsg("user", "atual")
        ))
        assertTrue(p.indexOf("SISTEMA") < p.indexOf("primeira"))
        assertTrue(p.indexOf("primeira") < p.indexOf("BLACK: resposta"))
        assertTrue(p.endsWith("atual"))
    }

    @Test fun dropsOldestHistoryWhenOverBudget() {
        val long = "x".repeat(100)
        val p = PromptBuilder.flatten(listOf(
            ChatMsg("user", "antiga$long"),
            ChatMsg("assistant", "meio$long"),
            ChatMsg("user", "recente$long"),
            ChatMsg("assistant", "ultima$long"),
            ChatMsg("user", "atual")
        ), maxHistoryChars = 260)
        assertFalse(p.contains("antiga"))
        assertTrue(p.contains("recente"))
        assertTrue(p.contains("ultima"))
    }
}
