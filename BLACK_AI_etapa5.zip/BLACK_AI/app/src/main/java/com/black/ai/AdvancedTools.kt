package com.black.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ferramentas locais e conectores públicos. Nenhum código enviado pelo usuário é executado. */
object SafeCalculator {
    fun evaluate(expression: String): Double {
        require(expression.length <= 240) { "Expressão muito longa." }
        return Parser(expression).parse()
    }
    private class Parser(private val s: String) {
        private var p = 0
        fun parse(): Double { val v = expr(); ws(); require(p == s.length) { "Trecho inválido na posição $p" }; require(v.isFinite()) { "Resultado não finito." }; return v }
        private fun expr(): Double { var v = term(); while (true) { ws(); v = when { eat('+') -> v + term(); eat('-') -> v - term(); else -> return v } } }
        private fun term(): Double { var v = power(); while (true) { ws(); v = when { eat('*') -> v * power(); eat('/') -> { val d = power(); require(d != 0.0) { "Divisão por zero." }; v / d }; else -> return v } } }
        private fun power(): Double { var v = unary(); ws(); if (eat('^')) v = Math.pow(v, power()); return v }
        private fun unary(): Double { ws(); return when { eat('+') -> unary(); eat('-') -> -unary(); eat('(') -> expr().also { ws(); require(eat(')')) { "Falta fechar parênteses." } }; else -> number() } }
        private fun number(): Double { ws(); val start = p; while (p < s.length && (s[p].isDigit() || s[p] == '.' || s[p] == ',')) p++; require(start < p) { "Número esperado na posição $p" }; return s.substring(start, p).replace(',', '.').toDouble() }
        private fun ws() { while (p < s.length && s[p].isWhitespace()) p++ }
        private fun eat(c: Char): Boolean { if (p < s.length && s[p] == c) { p++; return true }; return false }
    }
}

object CodeInspector {
    fun inspect(source: String): String {
        require(source.length <= 200_000) { "Código limitado a 200 KB por análise." }
        val lines = source.lines()
        val findings = mutableListOf<String>()
        if (Regex("\\bTODO\\b|\\bFIXME\\b").containsMatchIn(source)) findings += "Há marcações TODO/FIXME pendentes."
        if (Regex("(password|secret|api[_-]?key)\\s*=\\s*[\"'][^\"']{6,}", RegexOption.IGNORE_CASE).containsMatchIn(source)) findings += "Possível segredo/chave escrito diretamente no código; mova para armazenamento seguro e revogue chaves expostas."
        if (Regex("http://(?!localhost|127\\.0\\.0\\.1)", RegexOption.IGNORE_CASE).containsMatchIn(source)) findings += "URL HTTP sem TLS encontrada; prefira HTTPS quando houver dados sensíveis."
        if (source.contains("!!")) findings += "Operador !! encontrado; pode causar NullPointerException."
        if (Regex("catch\\s*\\([^)]*\\)\\s*\\{\\s*\\}").containsMatchIn(source)) findings += "Bloco catch vazio encontrado; registre ou trate a falha."
        val braces = source.count { it == '{' } - source.count { it == '}' }
        val parens = source.count { it == '(' } - source.count { it == ')' }
        if (braces != 0) findings += "Chaves não balanceadas (diferença: $braces)."
        if (parens != 0) findings += "Parênteses não balanceados (diferença: $parens)."
        return buildString {
            append("Análise estática concluída. Linhas: ${lines.size}; caracteres: ${source.length}.\n")
            if (findings.isEmpty()) append("Nenhum padrão de risco simples foi identificado. Isso não garante que o código esteja correto.")
            else findings.forEach { append("• $it\n") }
            append("\nO BLACK CODE não executa código arbitrário no aparelho.")
        }
    }
}

object TextFileTools {
    suspend fun read(context: Context, uri: Uri, maxBytes: Int = 1_000_000): String = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= maxBytes) { "Arquivo excede o limite de 1 MB." }
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        } ?: error("Não foi possível abrir o arquivo.")
        bytes.toString(Charsets.UTF_8)
    }
    suspend fun write(context: Context, uri: Uri, content: String) = withContext(Dispatchers.IO) {
        require(content.length <= 2_000_000) { "Conteúdo excede o limite de 2 MB." }
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) } ?: error("Não foi possível gravar o arquivo.")
    }
}

object CsvExporter {
    fun fromRows(rows: List<List<String>>): String = rows.joinToString("\r\n") { row -> row.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" } }
}

object AndroidActions {
    fun calendarIntent(title: String, description: String, beginMillis: Long, endMillis: Long): Intent {
        require(title.isNotBlank() && endMillis > beginMillis) { "Informe título e horário final posterior ao inicial." }
        return Intent(Intent.ACTION_INSERT).setData(Uri.parse("content://com.android.calendar/events"))
            .putExtra("title", title).putExtra("description", description)
            .putExtra("beginTime", beginMillis).putExtra("endTime", endMillis)
    }
    fun shareText(text: String): Intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
}

object PublicConnectors {
    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000; conn.readTimeout = 15_000; conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "BLACK-AI-Android/0.5")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Servidor respondeu HTTP $code: ${body.take(240)}")
            return body
        } finally { conn.disconnect() }
    }
    suspend fun githubRepositories(query: String): String = withContext(Dispatchers.IO) {
        require(query.isNotBlank() && query.length <= 120) { "Informe o que deseja procurar no GitHub." }
        val q = URLEncoder.encode(query, "UTF-8")
        val json = JSONObject(get("https://api.github.com/search/repositories?q=$q&sort=stars&per_page=5", mapOf("Accept" to "application/vnd.github+json")))
        val items = json.getJSONArray("items")
        buildString {
            append("Repositórios públicos encontrados:\n")
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                append("• ${item.optString("full_name")} — ${item.optString("description")}\n")
                append("  ★ ${item.optInt("stargazers_count")} · ${item.optString("html_url")}\n")
            }
            if (items.length() == 0) append("Nenhum resultado.")
        }
    }
    suspend fun translate(text: String, source: String, target: String): String = withContext(Dispatchers.IO) {
        require(text.isNotBlank() && text.length <= 4000) { "Texto vazio ou maior que 4.000 caracteres." }
        require(source.matches(Regex("[a-z]{2,3}(-[A-Z]{2})?")) && target.matches(Regex("[a-z]{2,3}(-[A-Z]{2})?"))) { "Código de idioma inválido." }
        val q = URLEncoder.encode(text, "UTF-8")
        val pair = URLEncoder.encode("$source|$target", "UTF-8")
        val json = JSONObject(get("https://api.mymemory.translated.net/get?q=$q&langpair=$pair"))
        val status = json.optInt("responseStatus")
        require(status == 200) { json.optString("responseDetails", "Falha no serviço de tradução.") }
        json.getJSONObject("responseData").optString("translatedText")
    }
}
