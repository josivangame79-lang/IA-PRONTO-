package com.black.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Backup portátil das memórias. O usuário escolhe o arquivo e o local pelo seletor do Android. */
object MemoryBackup {
    suspend fun export(context: Context, dao: BlackDao, uri: Uri): Int = withContext(Dispatchers.IO) {
        val rows = dao.allMemories()
        val root = JSONObject().put("format", "black-ai-memory").put("version", 1)
        val data = JSONArray()
        rows.forEach { data.put(JSONObject().put("kind", it.kind).put("text", it.text).put("source", it.source).put("ts", it.ts)) }
        root.put("memories", data)
        context.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(root.toString(2)) }
        rows.size
    }

    suspend fun import(context: Context, dao: BlackDao, uri: Uri): Int = withContext(Dispatchers.IO) {
        val raw = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        require(raw.length <= 5_000_000) { "Arquivo de backup muito grande (limite de 5 MB)." }
        val root = JSONObject(raw)
        require(root.optString("format") == "black-ai-memory" && root.optInt("version") == 1) { "Formato de backup BLACK AI inválido ou incompatível." }
        val rows = root.getJSONArray("memories")
        var inserted = 0
        for (i in 0 until rows.length()) {
            val item = rows.getJSONObject(i)
            val value = item.optString("text").trim()
            if (value.isNotEmpty() && dao.countMemoryText(value) == 0) {
                dao.insertMemory(MemoryEntity(kind = item.optString("kind", "LONG"), text = value,
                    source = "backup:${item.optString("source", "local")}", ts = item.optLong("ts", System.currentTimeMillis())))
                inserted++
            }
        }
        inserted
    }
}
