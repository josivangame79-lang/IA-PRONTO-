package com.black.ai

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Ações que SEMPRE exigem autorização explícita do usuário (autonomia CONTROLLED). */
enum class SensitiveAction(val label: String) {
    SEND_MESSAGE("Enviar mensagens"),
    PURCHASE("Realizar compras"),
    DELETE_FILE("Excluir arquivos"),
    CHANGE_SETTINGS("Alterar configurações importantes"),
    ACCESS_PRIVATE("Acessar contas ou dados privados"),
    INSTALL_TOOL("Instalar ferramenta com permissão sensível"),
    MODIFY_CORE("Modificar o próprio núcleo")
}

class ActionLogger(private val dao: BlackDao) {
    suspend fun log(agent: String, action: String, status: String) {
        dao.insertLog(ActionLogEntity(agent = agent, action = action, status = status))
    }
}

data class ApprovalRequest(
    val agent: String,
    val action: SensitiveAction,
    val detail: String,
    val result: CompletableDeferred<Boolean> = CompletableDeferred()
)

/** Fila de autorizações: a UI mostra um diálogo; nada sensível acontece sem "permitir" (uma vez). */
class PermissionManager(private val logger: ActionLogger) {
    private val _pending = MutableStateFlow<ApprovalRequest?>(null)
    val pending: StateFlow<ApprovalRequest?> = _pending
    private val mutex = Mutex()

    suspend fun request(agent: String, action: SensitiveAction, detail: String): Boolean =
        mutex.withLock {
            val r = ApprovalRequest(agent, action, detail)
            _pending.value = r
            logger.log(agent, "Pedido: ${action.label} — $detail", "AGUARDANDO")
            try {
                val ok = r.result.await()
                logger.log(agent, "${action.label}", if (ok) "APROVADO" else "NEGADO")
                ok
            } finally {
                _pending.value = null
            }
        }

    fun resolve(ok: Boolean) { _pending.value?.result?.complete(ok) }
    fun denyAll() = resolve(false)
}
