package com.black.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class ChatMsg(val role: String, val content: String)

class NoEngineException(message: String) : Exception(message)

interface LlmEngine {
    val name: String
    suspend fun isReady(): Boolean
    suspend fun chat(msgs: List<ChatMsg>): String
}

/** Monta um único prompt de texto (modelos locais pequenos têm contexto curto: o histórico é limitado). */
object PromptBuilder {
    fun flatten(msgs: List<ChatMsg>, maxHistoryChars: Int = 5000): String {
        val system = msgs.filter { it.role == "system" }.joinToString("\n") { it.content }
        val convo = msgs.filter { it.role != "system" }
        val last = convo.lastOrNull() ?: return system
        val kept = ArrayDeque<String>()
        var used = 0
        for (m in convo.dropLast(1).asReversed()) {
            val line = (if (m.role == "user") "Usuário: " else "BLACK: ") + m.content
            if (used + line.length > maxHistoryChars) break
            kept.addFirst(line)
            used += line.length
        }
        return buildString {
            if (system.isNotBlank()) { append(system); append("\n\n") }
            if (kept.isNotEmpty()) { append("Conversa até agora:\n"); append(kept.joinToString("\n")); append("\n\n") }
            append("Mensagem atual do usuário:\n")
            append(last.content)
        }
    }
}

/** Servidor próprio com API compatível com OpenAI (/v1/chat/completions): llama.cpp server, Ollama, vLLM etc. */
class RemoteEngine(private val settings: Settings) : LlmEngine {
    override val name = "Servidor próprio"
    override suspend fun isReady() = settings.serverUrl.isNotBlank()

    override suspend fun chat(msgs: List<ChatMsg>): String = withContext(Dispatchers.IO) {
        val url = URL(settings.serverUrl.trimEnd('/') + "/v1/chat/completions")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 120_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (settings.apiKey.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer ${settings.apiKey}")
            val body = JSONObject()
                .put("model", settings.model)
                .put("messages", JSONArray(msgs.map { JSONObject().put("role", it.role).put("content", it.content) }))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("Servidor respondeu $code: ${text.take(200)}")
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally {
            conn.disconnect()
        }
    }
}

/**
 * Escolhe o motor: online → servidor próprio, com o modelo local como reserva;
 * offline (ou "preferir local") → modelo local. Sem nenhum motor, explica o motivo.
 */
class LlmRouter(
    private val online: () -> Boolean,
    private val preferLocal: () -> Boolean,
    private val local: LlmEngine,
    private val remote: LlmEngine
) {
    private val _lastUsed = MutableStateFlow<String?>(null)
    val lastUsed: StateFlow<String?> = _lastUsed

    suspend fun chat(msgs: List<ChatMsg>): String {
        val isOnline = online()
        val order = if (preferLocal()) listOf(local, remote) else listOf(remote, local)
        val problems = mutableListOf<String>()
        for (e in order) {
            if (e === remote && !isOnline) { problems += "sem conexão (servidor próprio indisponível)"; continue }
            if (!e.isReady()) {
                problems += if (e === local) "nenhum modelo local ativo (Config > Modelos)" else "servidor próprio não configurado (Config)"
                continue
            }
            try {
                val answer = e.chat(msgs)
                _lastUsed.value = e.name
                return answer
            } catch (c: CancellationException) {
                throw c
            } catch (ex: Exception) {
                problems += "${e.name} falhou: ${ex.message ?: ex.javaClass.simpleName}"
            }
        }
        throw NoEngineException("Nenhum motor de IA respondeu: ${problems.joinToString("; ")}. Comandos de memória e data/hora funcionam offline.")
    }
}
