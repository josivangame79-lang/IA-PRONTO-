package com.black.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class AgentRouterTest {
    @Test fun routesGeneralWebResearch() {
        assertEquals(BlackTask.RESEARCH, AgentRouter.route("Pesquise na web sobre energia solar"))
    }

    @Test fun routesAcademicResearchFirst() {
        assertEquals(BlackTask.SCHOLAR, AgentRouter.route("Faça uma pesquisa científica sobre energia solar"))
    }

    @Test fun routesPlanning() {
        assertEquals(BlackTask.PLANNER, AgentRouter.route("Crie um plano para estudar matemática"))
    }

    @Test fun routesAnalysis() {
        assertEquals(BlackTask.ANALYST, AgentRouter.route("Compare estas duas opções"))
    }

    @Test fun leavesOrdinaryChatAlone() {
        assertEquals(BlackTask.CHAT, AgentRouter.route("Explique o que é inteligência artificial"))
    }
}
