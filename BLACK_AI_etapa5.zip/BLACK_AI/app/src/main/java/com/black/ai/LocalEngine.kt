package com.black.ai

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

data class LocalStatus(val text: String, val loading: Boolean = false, val error: Boolean = false)

/**
 * Modelo local offline via LiteRT-LM (CPU). Carrega o modelo na 1ª resposta (pode levar vários
 * segundos) e o mantém na memória; é descarregado quando o app vai para segundo plano.
 */
class LocalEngine(private val ctx: Context, private val store: ModelStore) : LlmEngine {
    override val name = "Modelo local"

    private val lock = Mutex()
    private var engine: Engine? = null
    private var loadedPath: String? = null

    private val _status = MutableStateFlow(
        LocalStatus(if (store.activeFile() == null) "Nenhum modelo ativo" else "Modelo selecionado (carrega ao usar)")
    )
    val status: StateFlow<LocalStatus> = _status

    override suspend fun isReady() = store.activeFile() != null

    override suspend fun chat(msgs: List<ChatMsg>): String = lock.withLock {
        val file = store.activeFile() ?: throw NoEngineException("Nenhum modelo local ativo")
        withContext(Dispatchers.Default) {
            val e = ensureEngine(file)
            val prompt = PromptBuilder.flatten(msgs)
            val sb = StringBuilder()
            e.createConversation().use { conv ->
                conv.sendMessageAsync(prompt).collect { sb.append(it.toString()) }
            }
            sb.toString().trim().ifEmpty { throw IllegalStateException("O modelo local não devolveu texto") }
        }
    }

    private fun ensureEngine(file: File): Engine {
        val current = engine
        if (current != null && loadedPath == file.absolutePath) return current
        closeEngine()
        _status.value = LocalStatus("Carregando ${file.name}… (pode demorar)", loading = true)
        try {
            val e = Engine(EngineConfig(modelPath = file.absolutePath, backend = Backend.CPU(), cacheDir = ctx.cacheDir.path))
            e.initialize()
            engine = e
            loadedPath = file.absolutePath
            _status.value = LocalStatus("Pronto: ${file.name}")
            return e
        } catch (ex: CancellationException) {
            _status.value = LocalStatus("Carregamento cancelado")
            throw ex
        } catch (ex: Throwable) {
            val msg = ex.message ?: ex.javaClass.simpleName
            _status.value = LocalStatus("Erro ao carregar: $msg", error = true)
            throw IllegalStateException("Falha ao carregar o modelo local: $msg")
        }
    }

    private fun closeEngine() {
        try { engine?.close() } catch (_: Exception) { }
        engine = null
        loadedPath = null
    }

    /** Libera a memória do modelo (ele recarrega sozinho na próxima resposta). */
    suspend fun unload() = lock.withLock {
        closeEngine()
        _status.value = LocalStatus(if (store.activeFile() == null) "Nenhum modelo ativo" else "Descarregado (carrega ao usar)")
    }
}
