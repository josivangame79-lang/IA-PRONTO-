package com.black.ai

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.DisposableEffect
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val tabs = listOf("💬" to "Chat", "🤖" to "Agentes", "🧰" to "Ferramentas", "🧠" to "Memória", "⚙️" to "Config")

@Composable
fun BlackRoot(c: Container) {
    var tab by remember { mutableStateOf(0) }
    val net by c.net.state.collectAsState()
    val forced by c.settings.forceOffline.collectAsState()
    val busy by c.core.busy.collectAsState()
    val pending by c.perms.pending.collectAsState()

    Scaffold(
        topBar = { TopBar(net, forced, busy || pending != null) { c.core.stop() } },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon) },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatScreen(c)
                1 -> AgentsScreen(c)
                2 -> ToolsScreen(c)
                3 -> MemoryScreen(c)
                else -> SettingsScreen(c)
            }
        }
    }

    pending?.let { req ->
        AlertDialog(
            onDismissRequest = { c.perms.resolve(false) },
            title = { Text("Autorização necessária") },
            text = { Text("${req.agent} quer: ${req.action.label}\n\nPedido: ${req.detail}") },
            confirmButton = { TextButton(onClick = { c.perms.resolve(true) }) { Text("Permitir (uma vez)") } },
            dismissButton = { TextButton(onClick = { c.perms.resolve(false) }) { Text("Negar") } }
        )
    }
}

@Composable
private fun TopBar(net: NetState, forced: Boolean, canStop: Boolean, onStop: () -> Unit) {
    val (label, color) = when {
        forced -> "OFFLINE (forçado)" to AlertRed
        net == NetState.OFFLINE -> "OFFLINE" to AlertRed
        net == NetState.WIFI -> "ONLINE · Wi-Fi" to OkGreen
        else -> "ONLINE · dados móveis" to BlueCyan
    }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("BLACK", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = BlueCyan)
        Spacer(Modifier.width(12.dp))
        Text("● $label", color = color, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onStop,
            enabled = canStop,
            colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = Color.White)
        ) { Text("PARAR") }
    }
}

@Composable
private fun ChatScreen(c: Container) {
    val msgs by c.dao.messages().collectAsState(initial = emptyList())
    val busy by c.core.busy.collectAsState()
    val localStatus by c.local.status.collectAsState()
    val lastUsed by c.llm.lastUsed.collectAsState()
    var input by remember { mutableStateOf("") }
    val context = LocalContext.current
    val tts = remember { TextToSpeech(context, null) }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = listOf(input, spoken).filter { it.isNotBlank() }.joinToString(" ")
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o BLACK")
            }
            runCatching { speechLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Reconhecimento de voz indisponível neste aparelho.", Toast.LENGTH_SHORT).show() }
        }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item {
                Text(
                    "Olá! Eu sou o BLACK.\nTente: \"lembre que meu aniversário é em março\", \"o que você sabe sobre aniversário\" ou \"que horas são\". Para conversar com a IA, configure um servidor ou importe um modelo local em Config.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(msgs, key = { it.id }) { m ->
                val mine = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier
                            .background(if (mine) BlueMain else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .fillMaxWidth(0.85f)
                    ) {
                        Column {
                            Text(m.content, color = Color.White)
                            if (!mine) TextButton(onClick = { tts.setLanguage(Locale("pt", "BR")); tts.speak(m.content, TextToSpeech.QUEUE_FLUSH, null, "black-${m.id}") }) {
                                Text("▶ Ouvir", color = BlueCyan, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            if (busy) item {
                Text(if (localStatus.loading) localStatus.text else "BLACK está pensando…", color = BlueCyan, fontSize = 12.sp)
            } else if (lastUsed != null && msgs.isNotEmpty()) item {
                Text("Última resposta de IA: $lastUsed", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Mensagem") },
                maxLines = 4
            )
            Spacer(Modifier.width(4.dp))
            TextButton(onClick = {
                if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o BLACK")
                    }
                    runCatching { speechLauncher.launch(intent) }.onFailure { Toast.makeText(context, "Reconhecimento de voz indisponível.", Toast.LENGTH_SHORT).show() }
                } else micPermission.launch(android.Manifest.permission.RECORD_AUDIO)
            }, enabled = !busy) { Text("🎙") }
            Button(onClick = { c.core.submit(input); input = "" }, enabled = !busy && input.isNotBlank()) { Text("Enviar") }
        }
    }
}

@Composable
private fun AgentsScreen(c: Container) {
    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Núcleo: BLACK AI CORE (ativo) — recebe a mensagem, roteia, aplica permissões e responde.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(c.core.agents, key = { it.info.id }) { a ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row {
                        Text(a.info.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(if (a.info.implemented) "ATIVO" else "PLANEJADO", color = if (a.info.implemented) OkGreen else Color(0xFFFFB300), fontSize = 12.sp)
                    }
                    Text(a.info.role, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    if (a.info.note.isNotBlank()) Text(a.info.note, color = BlueCyan, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ToolsScreen(c: Container) {
    val disabled by c.tools.disabled.collectAsState()
    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { AdvancedToolsPanel(c) }
        item { Text("Catálogo de ferramentas", fontWeight = FontWeight.Bold) }
        items(c.tools.all, key = { it.id }) { t ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.name, fontWeight = FontWeight.Bold)
                        Text("${t.category} · " + (if (t.implemented) "disponível" else "PLANEJADO"), fontSize = 12.sp,
                            color = if (t.implemented) OkGreen else Color(0xFFFFB300))
                        if (t.note.isNotBlank()) Text(t.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = t.implemented && t.id !in disabled, enabled = t.implemented, onCheckedChange = { c.tools.setEnabled(t.id, it) })
                }
            }
        }
    }
}


@Composable
private fun AdvancedToolsPanel(c: Container) {
    val context = LocalContext.current
    var expression by remember { mutableStateOf("(12 + 8) * 3") }
    var calcResult by remember { mutableStateOf("") }
    var sourceCode by remember { mutableStateOf("") }
    var codeResult by remember { mutableStateOf("") }
    var githubQuery by remember { mutableStateOf("android kotlin") }
    var githubResult by remember { mutableStateOf("") }
    var translateText by remember { mutableStateOf("") }
    var translateResult by remember { mutableStateOf("") }
    var fileText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.scope.launch {
            runCatching { TextFileTools.read(context, uri) }
                .onSuccess { fileText = it; Toast.makeText(context, "Arquivo carregado.", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, "Falha ao ler: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) c.scope.launch {
            runCatching { TextFileTools.write(context, uri, fileText) }
                .onSuccess { Toast.makeText(context, "Arquivo salvo.", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, "Falha ao salvar: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) c.scope.launch {
            runCatching { TextFileTools.write(context, uri, CsvExporter.fromRows(listOf(listOf("BLACK AI", "Exportação"), listOf("Conteúdo", fileText.take(30000)))) }
                .onSuccess { Toast.makeText(context, "CSV salvo.", Toast.LENGTH_SHORT).show() }
                .onFailure { Toast.makeText(context, "Falha ao exportar: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("BLACK TOOLBOX", color = BlueCyan, fontWeight = FontWeight.Bold)
            Text("Ferramentas locais e conectores online. Ações externas sempre abrem para sua revisão.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Calculadora segura", fontWeight = FontWeight.Bold)
            OutlinedTextField(expression, { expression = it }, Modifier.fillMaxWidth(), label = { Text("Ex.: (12 + 8) * 3") }, singleLine = true)
            Button(onClick = { calcResult = runCatching { SafeCalculator.evaluate(expression).toString() }.getOrElse { "Erro: ${it.message}" } }) { Text("Calcular") }
            if (calcResult.isNotBlank()) Text("Resultado: $calcResult")
            androidx.compose.material3.HorizontalDivider()
            Text("BLACK CODE · análise estática", fontWeight = FontWeight.Bold)
            OutlinedTextField(sourceCode, { sourceCode = it }, Modifier.fillMaxWidth(), label = { Text("Cole um trecho de código") }, minLines = 3, maxLines = 6)
            Button(onClick = { codeResult = runCatching { CodeInspector.inspect(sourceCode) }.getOrElse { "Erro: ${it.message}" } }, enabled = sourceCode.isNotBlank()) { Text("Analisar código") }
            if (codeResult.isNotBlank()) Text(codeResult, fontSize = 12.sp)
            androidx.compose.material3.HorizontalDivider()
            Text("GitHub · repositórios públicos", fontWeight = FontWeight.Bold)
            OutlinedTextField(githubQuery, { githubQuery = it }, Modifier.fillMaxWidth(), label = { Text("Buscar repositórios") }, singleLine = true)
            Button(onClick = { busy = true; c.scope.launch { githubResult = runCatching { PublicConnectors.githubRepositories(githubQuery) }.getOrElse { "Falha: ${it.message}" }; busy = false } }, enabled = !busy && githubQuery.isNotBlank()) { Text(if (busy) "Consultando…" else "Pesquisar GitHub") }
            if (githubResult.isNotBlank()) Text(githubResult, fontSize = 12.sp)
            androidx.compose.material3.HorizontalDivider()
            Text("Tradução online · português para inglês", fontWeight = FontWeight.Bold)
            OutlinedTextField(translateText, { translateText = it }, Modifier.fillMaxWidth(), label = { Text("Texto para traduzir") }, minLines = 2)
            Button(onClick = { busy = true; c.scope.launch { translateResult = runCatching { PublicConnectors.translate(translateText, "pt", "en") }.getOrElse { "Falha: ${it.message}" }; busy = false } }, enabled = !busy && translateText.isNotBlank()) { Text("Traduzir para inglês") }
            if (translateResult.isNotBlank()) Text(translateResult, fontSize = 12.sp)
            androidx.compose.material3.HorizontalDivider()
            Text("Arquivos autorizados", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openFile.launch(arrayOf("text/*", "application/json", "application/xml")) }) { Text("Abrir texto") }
                TextButton(onClick = { saveFile.launch("black-ai-notas.txt") }, enabled = fileText.isNotEmpty()) { Text("Salvar TXT") }
                TextButton(onClick = { saveCsv.launch("black-ai-export.csv") }, enabled = fileText.isNotEmpty()) { Text("Exportar CSV") }
            }
            if (fileText.isNotEmpty()) Text("Arquivo carregado: ${fileText.length} caracteres", fontSize = 11.sp, color = OkGreen)
            Button(onClick = {
                val now = System.currentTimeMillis()
                val intent = AndroidActions.calendarIntent("Lembrete do BLACK AI", "Evento criado a partir do BLACK AI", now + 60_000, now + 3_660_000)
                runCatching { context.startActivity(Intent.createChooser(intent, "Adicionar ao calendário")) }
                    .onFailure { Toast.makeText(context, "Nenhum calendário compatível encontrado.", Toast.LENGTH_SHORT).show() }
            }) { Text("Criar evento no calendário") }
            TextButton(onClick = { runCatching { context.startActivity(Intent.createChooser(AndroidActions.shareText(fileText.ifBlank { "BLACK AI" }), "Compartilhar")) } }) { Text("Compartilhar texto") }
        }
    }
}

@Composable
private fun MemoryScreen(c: Container) {
    val mems by c.dao.memories().collectAsState(initial = emptyList())
    val context = LocalContext.current
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) c.scope.launch { runCatching { MemoryBackup.export(context, c.dao, uri) }.onSuccess { Toast.makeText(context, "$it memórias exportadas.", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(context, "Falha no backup: ${it.message}", Toast.LENGTH_LONG).show() } }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.scope.launch { runCatching { MemoryBackup.import(context, c.dao, uri) }.onSuccess { Toast.makeText(context, "$it novas memórias importadas.", Toast.LENGTH_SHORT).show() }.onFailure { Toast.makeText(context, "Falha na importação: ${it.message}", Toast.LENGTH_LONG).show() } }
    }
    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Memória contextual local: o BLACK recupera lembranças por relevância e recência. Não há treinamento automático do modelo.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { exportLauncher.launch("black-ai-memories.json") }) { Text("Exportar backup") }
                TextButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json")) }) { Text("Importar") }
            }
            Text("O arquivo contém suas memórias. Guarde-o em local privado.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (mems.isEmpty()) item { Text("Nenhuma memória ainda. No chat, diga: \"lembre que ...\"", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(mems, key = { it.id }) { m ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.text)
                        Text(fmt.format(Date(m.ts)), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { c.scope.launch { c.dao.deleteMemory(m.id) } }) { Text("Apagar", color = AlertRed) }
                }
            }
        }
    }
}

@Composable
private fun GeneralSettings(c: Container) {
    val forced by c.settings.forceOffline.collectAsState()
    val log by c.dao.log().collectAsState(initial = emptyList())
    var url by remember { mutableStateOf(c.settings.serverUrl) }
    var model by remember { mutableStateOf(c.settings.model) }
    var key by remember { mutableStateOf(c.settings.apiKey) }
    var saved by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm:ss", Locale("pt", "BR")) }

    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Autonomia: CONTROLLED (fixa). Ações sensíveis sempre pedem sua autorização; o botão PARAR cancela tudo.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Text("Servidor de IA (API compatível com OpenAI)", fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(url, { url = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Endereço (ex.: http://192.168.0.10:8080)") }, singleLine = true) }
        item { OutlinedTextField(model, { model = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Modelo") }, singleLine = true) }
        item { OutlinedTextField(key, { key = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("Chave de API (opcional, guardada criptografada)") }, singleLine = true, visualTransformation = PasswordVisualTransformation()) }
        item {
            Button(onClick = { c.settings.serverUrl = url; c.settings.model = model; c.settings.apiKey = key; saved = true }) { Text(if (saved) "Salvo ✓" else "Salvar") }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Forçar modo offline", Modifier.weight(1f))
                Switch(checked = forced, onCheckedChange = { c.settings.setForceOffline(it) })
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("EVOLUÇÃO BLACK", fontWeight = FontWeight.Bold, color = BlueCyan)
                    Text("Ainda não implementado (etapa 6). Regra já definida: nenhum componente crítico muda sem autorização, testes e backup.", fontSize = 13.sp)
                }
            }
        }
        item { Text("Histórico de ações", fontWeight = FontWeight.Bold) }
        if (log.isEmpty()) item { Text("Sem ações registradas.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(log, key = { it.id }) { l ->
            Text("${fmt.format(Date(l.ts))} · ${l.agent} · ${l.status}\n${l.action}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}


private fun mb(bytes: Long) = bytes / (1024 * 1024)

@Composable
private fun SettingsScreen(c: Container) {
    var section by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { section = 0 }, enabled = section != 0) { Text("Geral") }
            Button(onClick = { section = 1 }, enabled = section != 1) { Text("Modelos") }
        }
        Box(Modifier.weight(1f)) { if (section == 0) GeneralSettings(c) else ModelsScreen(c) }
    }
}

@Composable
private fun ModelsScreen(c: Container) {
    val models by c.modelStore.models.collectAsState()
    val active by c.modelStore.active.collectAsState()
    val imp by c.modelStore.importState.collectAsState()
    val status by c.local.status.collectAsState()
    val prefer by c.settings.preferLocal.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) c.modelStore.importFrom(uri)
    }

    LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Modelo local (offline) — LiteRT-LM, CPU", fontWeight = FontWeight.Bold) }
        item {
            Text(
                "Importe um arquivo .litertlm (ex.: Gemma3-1B-IT, da comunidade LiteRT no Hugging Face). O app não baixa modelos sozinho: a licença de cada modelo deve ser aceita por você. Modelos ocupam centenas de MB a vários GB; a 1ª resposta demora porque o modelo é carregado.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
            )
        }
        item { Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !imp.running) { Text("Importar modelo (.litertlm)") } }
        if (imp.running) item {
            Column {
                Text("Copiando… ${mb(imp.copied)} MB" + (if (imp.total > 0) " de ${mb(imp.total)} MB" else ""))
                if (imp.total > 0) LinearProgressIndicator(progress = { (imp.copied.toFloat() / imp.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                TextButton(onClick = { c.modelStore.cancelImport() }) { Text("Cancelar") }
            }
        }
        imp.error?.let { e -> item { Text(e, color = AlertRed) } }
        imp.done?.let { d -> item { Text("Importado: $d", color = OkGreen) } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Preferir modelo local mesmo online", Modifier.weight(1f))
                Switch(checked = prefer, onCheckedChange = { c.settings.setPreferLocal(it) })
            }
        }
        item { Text("Estado: ${status.text}", color = if (status.error) AlertRed else BlueCyan, fontSize = 13.sp) }
        item { TextButton(onClick = { c.scope.launch { c.local.unload() } }) { Text("Descarregar da memória") } }
        if (models.isEmpty()) item { Text("Nenhum modelo importado.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(models, key = { it.name }) { m ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, fontWeight = FontWeight.Bold)
                        Text("${mb(m.sizeBytes)} MB" + (if (active == m.name) " · ATIVO" else ""), fontSize = 12.sp,
                            color = if (active == m.name) OkGreen else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (active != m.name) TextButton(onClick = { c.modelStore.setActive(m.name) }) { Text("Usar") }
                    TextButton(onClick = { c.scope.launch { c.local.unload(); c.modelStore.delete(m.name) } }) { Text("Apagar", color = AlertRed) }
                }
            }
        }
    }
}
