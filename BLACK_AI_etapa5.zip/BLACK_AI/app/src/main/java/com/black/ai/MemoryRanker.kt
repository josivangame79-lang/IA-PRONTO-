package com.black.ai

import java.text.Normalizer
import kotlin.math.ln

/** Recuperação contextual inteiramente local. Não é embedding neural: usa TF-IDF simples + frase + recência. */
object MemoryRanker {
    private val stop = setOf("para", "como", "sobre", "quando", "onde", "qual", "quais", "porque", "porquê", "isso", "essa", "esse", "aquela", "aquele", "com", "sem", "uma", "umas", "uns", "dos", "das", "que", "the", "and", "with", "from", "this", "that")

    private fun tokens(text: String): List<String> {
        val normalized = Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return Regex("[\\p{L}\\p{N}]{2,}").findAll(normalized)
            .map { it.value }.filterNot { it in stop }.toList()
    }

    fun rank(query: String, memories: List<MemoryEntity>, now: Long = System.currentTimeMillis()): List<MemoryEntity> {
        val q = tokens(query).toSet()
        if (q.isEmpty() || memories.isEmpty()) return emptyList()
        val docs = memories.map { tokens(it.text).toSet() }
        val idf = q.associateWith { term ->
            ln(1.0 + memories.size.toDouble() / (1.0 + docs.count { term in it }))
        }
        return memories.mapIndexedNotNull { index, memory ->
            val terms = docs[index]
            val overlap = q.intersect(terms)
            if (overlap.isEmpty()) return@mapIndexedNotNull null
            val lexical = overlap.sumOf { idf[it] ?: 0.0 } / (q.sumOf { idf[it] ?: 0.0 }.coerceAtLeast(0.001))
            val phrase = if (memory.text.contains(query, ignoreCase = true)) 0.35 else 0.0
            val ageDays = ((now - memory.ts).coerceAtLeast(0L) / 86_400_000.0)
            val recency = 0.08 / (1.0 + ageDays / 30.0)
            memory to (lexical + phrase + recency)
        }.sortedByDescending { it.second }.map { it.first }
    }
}
